local fruits = {
    cherry = {
        sheet = "spr16",
        quad = 78,
        score = 100,
    },
    strawberry = {
        sheet = "spr16",
        quad = 79,
        score = 300,
    },
    peach = {
        sheet = "spr16",
        quad = 80,
        score = 500,
    },
    apple = {
        sheet = "spr16",
        quad = 81,
        score = 700,
    },
    melon = {
        sheet = "spr16",
        quad = 82,
        score = 1000,
    },
    galaxian = {
        sheet = "spr16",
        quad = 83,
        score = 2000,
    },
    bell = {
        sheet = "spr16",
        quad = 84,
        score = 3000,
    },
    key = {
        sheet = "spr16",
        quad = 85,
        score = 5000,
    },
    x = 14 * 8,
    y = 20 * 8 + 4,
}

return fruits