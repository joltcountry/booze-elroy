local fruits = {
    cherry = {
        sheet = "spr16",
        quad = 62,
        score = 100,
    },
    strawberry = {
        sheet = "spr16",
        quad = 63,
        score = 300,
    },
    peach = {
        sheet = "spr16",
        quad = 64,
        score = 500,
    },
    apple = {
        sheet = "spr16",
        quad = 65,
        score = 700,
    },
    melon = {
        sheet = "spr16",
        quad = 66,
        score = 1000,
    },
    galaxian = {
        sheet = "spr16",
        quad = 67,
        score = 2000,
    },
    bell = {
        sheet = "spr16",
        quad = 68,
        score = 3000,
    },
    key = {
        sheet = "spr16",
        quad = 69,
        score = 5000,
    },
    x = 14 * 8,
    y = 20 * 8 + 4,
}

return fruits